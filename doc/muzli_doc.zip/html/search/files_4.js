var searchData=
[
  ['parancsok_2emd',['parancsok.md',['../de/dc0/parancsok_8md.html',1,'']]]
];
