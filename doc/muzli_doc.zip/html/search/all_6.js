var searchData=
[
  ['onconnect',['onConnect',['../d8/db2/class_robot_handler.html#a695b6858a5f819bd5bed2925800d5e4d',1,'RobotHandler']]],
  ['ondisconnect',['onDisconnect',['../d8/db2/class_robot_handler.html#afe8f461bbc75761e677017fc2888e548',1,'RobotHandler']]],
  ['onsend',['onSend',['../d8/db2/class_robot_handler.html#a3e8f8076d1860f7fda962e15c6627ade',1,'RobotHandler']]]
];
