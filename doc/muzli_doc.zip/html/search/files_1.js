var searchData=
[
  ['diagramok_2emd',['diagramok.md',['../da/d6b/diagramok_8md.html',1,'']]]
];
