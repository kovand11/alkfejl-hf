var searchData=
[
  ['uml_20diagramok',['UML diagramok',['../da/def/diagramok.html',1,'']]]
];
