var searchData=
[
  ['parancsok_20leírása',['Parancsok leírása',['../d8/daa/commands.html',1,'']]]
];
