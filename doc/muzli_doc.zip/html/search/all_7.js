var searchData=
[
  ['parancsok_20leírása',['Parancsok leírása',['../d8/daa/commands.html',1,'']]],
  ['parancsok_2emd',['parancsok.md',['../de/dc0/parancsok_8md.html',1,'']]]
];
