var searchData=
[
  ['alkalmazásfejlesztés_20házi_20feladat',['Alkalmazásfejlesztés Házi Feladat',['../index.html',1,'']]]
];
